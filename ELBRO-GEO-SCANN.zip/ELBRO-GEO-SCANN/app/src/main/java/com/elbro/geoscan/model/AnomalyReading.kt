package com.elbro.geoscan.model

data class AnomalyReading(
    val timestampMillis: Long,
    val magneticFieldMicroTesla: Float,
    val baselineMicroTesla: Float,
    val deviationMicroTesla: Float,
    val latitude: Double?,
    val longitude: Double?,
    val gpsAccuracyMeters: Float?
)

enum class AnomalyStatus {
    NORMAL,
    WATCH,
    ANOMALY
}

/**
 * Simple threshold-based classification of the deviation between the
 * current magnetic field magnitude and the locally calibrated baseline.
 *
 * These thresholds (in microtesla, µT) are heuristic and can be tuned;
 * they do NOT identify the physical cause of a detected variation.
 */
fun classifyDeviation(deviationMicroTesla: Float): AnomalyStatus = when {
    deviationMicroTesla >= 15f -> AnomalyStatus.ANOMALY
    deviationMicroTesla >= 7f -> AnomalyStatus.WATCH
    else -> AnomalyStatus.NORMAL
}
