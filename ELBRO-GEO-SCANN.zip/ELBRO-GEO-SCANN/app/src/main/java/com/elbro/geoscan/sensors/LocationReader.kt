package com.elbro.geoscan.sensors

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper

/**
 * Reads real device GPS/network location updates directly via the
 * platform LocationManager (no Google Play Services dependency,
 * so no Maps/Location API key is required).
 */
class LocationReader(
    context: Context,
    private val onLocation: (Location) -> Unit
) {
    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private val listener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            onLocation(location)
        }

        @Deprecated("Deprecated in Java, kept for API level compatibility")
        override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
    }

    @SuppressLint("MissingPermission")
    fun start() {
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        for (provider in providers) {
            if (locationManager.isProviderEnabled(provider)) {
                locationManager.requestLocationUpdates(
                    provider,
                    1000L,
                    0.5f,
                    listener,
                    Looper.getMainLooper()
                )
            }
        }
    }

    fun stop() {
        locationManager.removeUpdates(listener)
    }
}
