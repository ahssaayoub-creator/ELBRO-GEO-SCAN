# ELBRO GEO SCAN

Application Android native (Kotlin + Jetpack Compose) de détection des
**variations du champ magnétique de terrain**, à l'aide du **magnétomètre réel**
et du **GPS réel** du smartphone.

- **Package :** `com.elbro.geoscan`
- **Version :** 1.0.0
- **Langue de l'interface :** Français
- **Design :** sombre, technique, professionnel
- **Dépendances externes / clés API :** aucune. L'app utilise uniquement les
  capteurs et la localisation natifs d'Android (`SensorManager`,
  `LocationManager`) — pas de Google Maps, pas de Google Play Services, donc
  **aucune clé API n'est requise** pour compiler ou faire fonctionner l'app.

Ce projet est un **projet Android Studio complet et prêt à compiler** :
structure Gradle, module `app`, code Kotlin, ressources, manifeste et
workflow GitHub Actions sont tous en place.

---

## ⚠️ Limite scientifique importante

**ELBRO GEO SCAN ne détecte pas l'or, les métaux précieux ou un trésor de
façon spécifique.**

L'application mesure la **magnitude du champ magnétique ambiant** captée par
le magnétomètre du téléphone (capteur `TYPE_MAGNETIC_FIELD`), et calcule
l'écart entre la valeur instantanée et une **référence locale** calibrée au
démarrage (moyenne des ~40 premières mesures).

Un écart important ("anomalie") peut avoir de très nombreuses causes,
notamment :
- masses métalliques (ferraille, rebar, canalisations, véhicules) ;
- structures enterrées non liées à un trésor ;
- roches ou sols à forte teneur magnétique ;
- câbles électriques ou équipements électroniques à proximité ;
- interférences du téléphone lui-même (coque aimantée, haut-parleur, etc.).

Ce n'est **pas** un instrument de prospection scientifique certifié et cela
**ne remplace pas** un relevé géophysique professionnel (magnétomètre de
précision, résistivimètre, géoradar). Ce texte est aussi affiché dans l'app
via le bouton ⓘ (Informations).

---

## 1. Installation — Android Studio (méthode recommandée)

1. Installez **Android Studio** (Ladybug ou plus récent) :
   https://developer.android.com/studio
2. Ouvrez Android Studio → **File → Open** → sélectionnez le dossier
   `ELBRO-GEO-SCANN` (celui qui contient `settings.gradle.kts`).
3. Android Studio va :
   - détecter `gradle/wrapper/gradle-wrapper.properties` et proposer de
     générer le wrapper Gradle (`gradlew`) automatiquement — acceptez
     ("OK" / "Sync Now"). *Le fichier binaire `gradle-wrapper.jar` n'est
     volontairement pas versionné dans ce dépôt : Android Studio (ou la
     commande `gradle wrapper --gradle-version 8.7` si vous avez Gradle
     installé localement) le régénère tout seul.*
   - télécharger **Gradle 8.7** ;
   - vous proposer d'installer le SDK Android manquant (**API 34**,
     Build-Tools 34.0.0) si besoin — acceptez ;
   - générer automatiquement `local.properties` avec le chemin de votre SDK.
4. Attendez la fin de la synchronisation Gradle ("Gradle sync finished").
5. Branchez un téléphone Android (mode développeur + débogage USB activés)
   ou utilisez un émulateur — **notez qu'un émulateur ne dispose en général
   pas d'un vrai magnétomètre**, donc pour tester la mesure réelle du champ
   magnétique, un appareil physique est recommandé.
6. Cliquez sur **Run ▶** (ou **Build → Build Bundle(s)/APK(s) → Build
   APK(s)**).
7. L'APK généré se trouve dans :
   ```
   app/build/outputs/apk/debug/app-debug.apk
   app/build/outputs/apk/release/app-release-unsigned.apk   (build release)
   ```
8. Transférez le fichier `.apk` sur votre téléphone (câble, e-mail, Drive…)
   et installez-le (autorisez "Installer des applications inconnues" si
   demandé).

> **Remarque sur la signature :** le build `release` fourni ici n'est **pas
> signé** avec une clé de production (aucune `signingConfig` n'est
> configurée). C'est volontaire pour rester "prêt à compiler" sans
> nécessiter de keystore personnel. Pour publier sur le Play Store, il
> faudra générer votre propre keystore et ajouter un `signingConfig` dans
> `app/build.gradle.kts`.

---

## 2. Build automatique — GitHub Actions

Le workflow `.github/workflows/build.yml` est déclenché automatiquement à
chaque `push` sur `main`/`master`, sur chaque Pull Request, et peut aussi
être lancé manuellement.

**Ce qu'il fait, dans l'ordre :**
1. Checkout du dépôt.
2. Installation de JDK 17 (Temurin).
3. Pré-acceptation des licences du SDK Android (évite le blocage
   interactif "y/N" en CI).
4. Installation du SDK Android + `platform-tools`.
5. Installation de `platforms;android-34` et `build-tools;34.0.0`.
6. Installation de Gradle 8.7 et génération du wrapper (`gradlew`).
7. Exécution des tests unitaires (`./gradlew testDebugUnitTest`).
8. Build de l'APK debug (`./gradlew assembleDebug`).
9. Build de l'APK release (`./gradlew assembleRelease`).
10. Vérification que l'APK release existe bien.
11. Upload des deux APK (debug + release) comme **artifacts** du run.

**Pour récupérer l'APK depuis GitHub :**
1. Poussez ce projet sur votre dépôt `ELBRO-GEO-SCANN` (voir section 3).
2. Allez dans l'onglet **Actions** du dépôt.
3. Ouvrez le run le plus récent de "Build ELBRO GEO SCAN APK".
4. En bas de la page du run, section **Artifacts**, téléchargez
   `ELBRO-GEO-SCAN-release-apk` (ou `-debug-apk`).
5. C'est un fichier `.zip` contenant l'APK — décompressez-le puis installez
   l'APK sur votre téléphone.

---

## 3. Comment mettre ce projet sur votre dépôt GitHub

Votre dépôt actuel ne contenait que quelques ressources éparses (pas de
vrai module `app/`, pas de `build.gradle`), ce qui causait les échecs de
build précédents. Ce projet-ci est la structure complète et doit
**remplacer** le contenu actuel du dépôt.

**Option A — avec Git en ligne de commande (recommandé) :**
```bash
git clone https://github.com/ahssaayoub-creator/ELBRO-GEO-SCANN.git
cd ELBRO-GEO-SCANN
# copiez ici tous les fichiers/dossiers de ce projet (en écrasant l'existant)
git add -A
git commit -m "Add complete Android Studio project (ELBRO GEO SCAN)"
git push origin main
```

**Option B — via l'interface web GitHub :**
1. Ouvrez votre dépôt sur github.com.
2. **Add file → Upload files**.
3. Glissez-déposez le contenu du dossier du projet (les navigateurs récents
   permettent de glisser des dossiers entiers en conservant leur
   arborescence).
4. Committez directement sur `main`.

Une fois poussé, l'onglet **Actions** lancera automatiquement le build.

---

## 4. Structure complète du projet

```
ELBRO-GEO-SCANN/
├── .github/
│   └── workflows/
│       └── build.yml
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/com/elbro/geoscan/
│           │   ├── MainActivity.kt
│           │   ├── model/
│           │   │   └── AnomalyReading.kt
│           │   ├── sensors/
│           │   │   ├── MagnetometerReader.kt
│           │   │   └── LocationReader.kt
│           │   └── ui/theme/
│           │       ├── Color.kt
│           │       ├── Theme.kt
│           │       └── Type.kt
│           └── res/
│               ├── drawable/
│               │   ├── ic_launcher_background.xml
│               │   └── ic_launcher_foreground.xml
│               ├── mipmap-anydpi-v26/
│               │   ├── ic_launcher.xml
│               │   └── ic_launcher_round.xml
│               ├── values/
│               │   ├── colors.xml
│               │   ├── strings.xml
│               │   └── themes.xml
│               └── xml/
│                   ├── backup_rules.xml
│                   ├── data_extraction_rules.xml
│                   └── file_paths.xml
├── gradle/
│   └── wrapper/
│       └── gradle-wrapper.properties
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── .gitignore
└── README.md
```

*(`gradlew`, `gradlew.bat` et `gradle-wrapper.jar` ne sont pas versionnés —
ils sont générés automatiquement par Android Studio ou par l'étape
"Generate Gradle wrapper" du workflow CI, à partir de
`gradle-wrapper.properties`.)*

---

## 5. Ce qu'il vous reste exactement à faire pour obtenir l'APK

1. **Remplacez** le contenu de votre dépôt `ELBRO-GEO-SCANN` par ce projet
   (section 3 ci-dessus).
2. **Attendez** le workflow GitHub Actions (onglet *Actions*) — il doit
   passer en ✅ vert.
3. **Téléchargez** l'artifact `ELBRO-GEO-SCAN-release-apk` en bas de la
   page du run.
4. **Décompressez** le `.zip` téléchargé → vous obtenez le fichier
   `app-release-unsigned.apk`.
5. **Transférez-le** sur votre téléphone Android et installez-le (activez
   "sources inconnues" si demandé).

En parallèle, vous pouvez aussi ouvrir le projet dans **Android Studio**
(section 1) pour tester directement sur un appareil branché en USB, ce qui
est plus rapide pendant le développement.
