package com.elbro.geoscan.ui.theme

import androidx.compose.ui.graphics.Color

val BackgroundDark = Color(0xFF0B0F14)
val SurfaceDark = Color(0xFF141A21)
val SurfaceVariantDark = Color(0xFF1E2731)
val PrimaryGreen = Color(0xFF00E5A0)
val PrimaryVariantGreen = Color(0xFF00B583)
val SecondaryBlue = Color(0xFF3D8BFF)
val OnBackground = Color(0xFFE6EDF3)
val OnSurface = Color(0xFFC7D1DB)
val AnomalyAlert = Color(0xFFFF5C5C)
val AnomalyWarning = Color(0xFFFFB84D)
val AnomalyNormal = Color(0xFF3D8BFF)
