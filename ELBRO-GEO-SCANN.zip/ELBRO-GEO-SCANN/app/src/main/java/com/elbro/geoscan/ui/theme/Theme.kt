package com.elbro.geoscan.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val ElbroDarkColorScheme = darkColorScheme(
    primary = PrimaryGreen,
    onPrimary = BackgroundDark,
    primaryContainer = PrimaryVariantGreen,
    secondary = SecondaryBlue,
    background = BackgroundDark,
    onBackground = OnBackground,
    surface = SurfaceDark,
    onSurface = OnSurface,
    surfaceVariant = SurfaceVariantDark,
    error = AnomalyAlert
)

/**
 * ELBRO GEO SCAN always renders in a dark, technical theme by design,
 * regardless of the system light/dark setting.
 */
@Composable
fun ElbroGeoScanTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = ElbroDarkColorScheme,
        typography = AppTypography,
        content = content
    )
}
