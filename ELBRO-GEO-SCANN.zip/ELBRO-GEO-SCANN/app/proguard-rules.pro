# Add project specific ProGuard rules here.
# ELBRO GEO SCAN does not currently enable code shrinking (isMinifyEnabled = false).
# These rules are kept as a starting point if minification is enabled later.

-keep class com.elbro.geoscan.model.** { *; }
-keepattributes *Annotation*
