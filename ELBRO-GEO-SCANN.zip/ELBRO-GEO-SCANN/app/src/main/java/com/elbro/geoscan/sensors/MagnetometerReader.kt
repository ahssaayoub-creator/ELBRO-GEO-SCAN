package com.elbro.geoscan.sensors

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlin.math.sqrt

/**
 * Wraps the device magnetometer (TYPE_MAGNETIC_FIELD) and reports the
 * magnitude of the magnetic field vector in microtesla (µT).
 */
class MagnetometerReader(
    context: Context,
    private val onReading: (Float) -> Unit
) {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val magnetometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

    val isAvailable: Boolean get() = magnetometer != null

    private val listener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]
            val magnitude = sqrt(x * x + y * y + z * z)
            onReading(magnitude)
        }

        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
            // Not used, but required by the SensorEventListener interface.
        }
    }

    fun start() {
        magnetometer?.let {
            sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stop() {
        sensorManager.unregisterListener(listener)
    }
}
