package com.elbro.geoscan

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import com.elbro.geoscan.model.AnomalyReading
import com.elbro.geoscan.model.AnomalyStatus
import com.elbro.geoscan.model.classifyDeviation
import com.elbro.geoscan.sensors.LocationReader
import com.elbro.geoscan.sensors.MagnetometerReader
import com.elbro.geoscan.ui.theme.AnomalyAlert
import com.elbro.geoscan.ui.theme.AnomalyNormal
import com.elbro.geoscan.ui.theme.AnomalyWarning
import com.elbro.geoscan.ui.theme.ElbroGeoScanTheme
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

/**
 * ELBRO GEO SCAN
 *
 * Real-time magnetic field (magnetometer) + GPS logger.
 *
 * IMPORTANT SCIENTIFIC LIMITATION:
 * This app measures relative variations of the ambient magnetic field
 * as detected by the phone's built-in magnetometer. It does NOT identify
 * gold, treasure, or any specific buried object. Many things can cause a
 * magnetic anomaly (rebar, pipes, vehicles, electrical wiring, geology,
 * or the phone's own case/magnets). See the in-app disclaimer dialog.
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val initiallyGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        setContent {
            ElbroGeoScanTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    GeoScanScreen(initiallyGranted = initiallyGranted)
                }
            }
        }
    }
}

@Composable
fun GeoScanScreen(initiallyGranted: Boolean) {
    val context = LocalContext.current

    var permissionGranted by remember { mutableStateOf(initiallyGranted) }
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted -> permissionGranted = granted }

    LaunchedEffect(Unit) {
        if (!permissionGranted) {
            permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    var currentField by remember { mutableStateOf(0f) }
    var baseline by remember { mutableStateOf<Float?>(null) }
    val calibrationSamples = remember { mutableListOf<Float>() }
    var currentLocation by remember { mutableStateOf<Location?>(null) }
    val anomalies = remember { mutableStateListOf<AnomalyReading>() }
    var lastAnomalyLogAt by remember { mutableStateOf(0L) }
    var showInfoDialog by remember { mutableStateOf(false) }
    var exportMessage by remember { mutableStateOf<String?>(null) }

    DisposableEffect(permissionGranted) {
        val magnetometer = MagnetometerReader(context) { magnitude ->
            currentField = magnitude

            if (calibrationSamples.size < 40) {
                calibrationSamples.add(magnitude)
                if (calibrationSamples.size == 40) {
                    baseline = calibrationSamples.average().toFloat()
                }
            }

            val base = baseline
            if (base != null) {
                val deviation = abs(magnitude - base)
                val status = classifyDeviation(deviation)
                val now = System.currentTimeMillis()
                if (status == AnomalyStatus.ANOMALY && now - lastAnomalyLogAt > 4000L) {
                    lastAnomalyLogAt = now
                    anomalies.add(
                        0,
                        AnomalyReading(
                            timestampMillis = now,
                            magneticFieldMicroTesla = magnitude,
                            baselineMicroTesla = base,
                            deviationMicroTesla = deviation,
                            latitude = currentLocation?.latitude,
                            longitude = currentLocation?.longitude,
                            gpsAccuracyMeters = currentLocation?.accuracy
                        )
                    )
                }
            }
        }
        magnetometer.start()

        val locationReader = if (permissionGranted) {
            LocationReader(context) { location -> currentLocation = location }.also { it.start() }
        } else {
            null
        }

        onDispose {
            magnetometer.stop()
            locationReader?.stop()
        }
    }

    val deviation = baseline?.let { abs(currentField - it) } ?: 0f
    val status = if (baseline == null) AnomalyStatus.NORMAL else classifyDeviation(deviation)
    val statusColor = when (status) {
        AnomalyStatus.NORMAL -> AnomalyNormal
        AnomalyStatus.WATCH -> AnomalyWarning
        AnomalyStatus.ANOMALY -> AnomalyAlert
    }
    val statusLabel = when (status) {
        AnomalyStatus.NORMAL -> stringResource(R.string.status_normal)
        AnomalyStatus.WATCH -> stringResource(R.string.status_watch)
        AnomalyStatus.ANOMALY -> stringResource(R.string.status_anomaly)
    }
    val unit = stringResource(R.string.magnetic_field_unit)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(stringResource(R.string.home_title), style = MaterialTheme.typography.headlineMedium)
                Text(stringResource(R.string.home_subtitle), style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = { showInfoDialog = true }) {
                Icon(Icons.Default.Info, contentDescription = stringResource(R.string.info_button))
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(stringResource(R.string.magnetic_field_label), style = MaterialTheme.typography.labelSmall)
                Text("%.2f %s".format(currentField, unit), style = MaterialTheme.typography.headlineMedium)

                Spacer(modifier = Modifier.height(12.dp))

                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text(stringResource(R.string.baseline_label), style = MaterialTheme.typography.labelSmall)
                        Text(
                            baseline?.let { "%.2f %s".format(it, unit) } ?: "…",
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(stringResource(R.string.deviation_label), style = MaterialTheme.typography.labelSmall)
                        Text("%.2f %s".format(deviation, unit), style = MaterialTheme.typography.bodyLarge)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Surface(color = statusColor.copy(alpha = 0.15f), shape = MaterialTheme.shapes.small) {
                    Text(
                        statusLabel,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                if (!permissionGranted) {
                    Text(stringResource(R.string.permission_denied_message), style = MaterialTheme.typography.bodyMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(onClick = { permissionLauncher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }) {
                        Text(stringResource(R.string.permission_grant_button))
                    }
                } else {
                    val loc = currentLocation
                    if (loc == null) {
                        Text(stringResource(R.string.gps_waiting), style = MaterialTheme.typography.bodyMedium)
                    } else {
                        Text("Lat: %.6f   Lon: %.6f".format(loc.latitude, loc.longitude))
                        Text("${stringResource(R.string.gps_accuracy_label)}: %.1f m".format(loc.accuracy))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = {
                    calibrationSamples.clear()
                    baseline = null
                },
                modifier = Modifier.width(0.dp).weight(1f)
            ) {
                Text(stringResource(R.string.reset_baseline_button))
            }
            Button(
                onClick = { exportMessage = exportAnomaliesToCsv(context, anomalies) },
                modifier = Modifier.width(0.dp).weight(1f)
            ) {
                Text(stringResource(R.string.export_csv_button))
            }
        }

        exportMessage?.let {
            Spacer(modifier = Modifier.height(4.dp))
            Text(it, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(stringResource(R.string.history_title), style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(8.dp))

        if (anomalies.isEmpty()) {
            Text(stringResource(R.string.history_empty), style = MaterialTheme.typography.bodyMedium)
        } else {
            LazyColumn(modifier = Modifier.fillMaxWidth()) {
                items(anomalies) { reading ->
                    AnomalyRow(reading)
                    HorizontalDivider()
                }
            }
        }
    }

    if (showInfoDialog) {
        AlertDialog(
            onDismissRequest = { showInfoDialog = false },
            title = { Text(stringResource(R.string.scientific_disclaimer_title)) },
            text = { Text(stringResource(R.string.scientific_disclaimer_body)) },
            confirmButton = {
                TextButton(onClick = { showInfoDialog = false }) {
                    Text(stringResource(R.string.close_button))
                }
            }
        )
    }
}

@Composable
fun AnomalyRow(reading: AnomalyReading) {
    val formatter = remember { SimpleDateFormat("dd/MM HH:mm:ss", Locale.FRANCE) }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(formatter.format(Date(reading.timestampMillis)), style = MaterialTheme.typography.bodyMedium)
            if (reading.latitude != null && reading.longitude != null) {
                Text(
                    "%.6f, %.6f".format(reading.latitude, reading.longitude),
                    style = MaterialTheme.typography.labelSmall
                )
            }
        }
        Text(
            "+%.1f µT".format(reading.deviationMicroTesla),
            color = AnomalyAlert,
            fontWeight = FontWeight.Bold
        )
    }
}

private fun exportAnomaliesToCsv(
    context: android.content.Context,
    anomalies: List<AnomalyReading>
): String {
    return try {
        val exportsDir = File(context.getExternalFilesDir(null), "exports")
        if (!exportsDir.exists()) exportsDir.mkdirs()

        val file = File(exportsDir, "elbro_geoscan_${System.currentTimeMillis()}.csv")
        file.bufferedWriter().use { writer ->
            writer.write("timestamp,champ_magnetique_uT,reference_uT,ecart_uT,latitude,longitude,precision_gps_m\n")
            for (a in anomalies) {
                writer.write(
                    "${a.timestampMillis},${a.magneticFieldMicroTesla},${a.baselineMicroTesla}," +
                        "${a.deviationMicroTesla},${a.latitude ?: ""},${a.longitude ?: ""},${a.gpsAccuracyMeters ?: ""}\n"
                )
            }
        }

        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/csv"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Partager le fichier CSV"))
        "Export réussi : ${file.name}"
    } catch (e: Exception) {
        "Erreur lors de l'export : ${e.message}"
    }
}
